import { useContext } from 'react'
import { Context } from '../contexts/SushiProvider'

const useCrops = () => {
  const { crops } = useContext(Context)
  return crops
}

export default useCrops
