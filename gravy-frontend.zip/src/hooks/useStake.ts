import { useCallback } from 'react'

import useCrops from './useCrops'
import { useWallet } from 'use-wallet'

import { stake, getMasterChefContract } from '../crops/utils'

const useStake = (pid: number) => {
  const { account } = useWallet()
  const crops = useCrops()

  const handleStake = useCallback(
    async (amount: string) => {

      const masterfarmer = getMasterChefContract(crops)
      console.log(masterfarmer.options.address)

      console.log(amount)
      const txHash = await stake(
        getMasterChefContract(crops),
        pid,
        amount,
        account,
      )
      console.log(txHash)
    },
    [account, pid, crops],
  )

  return { onStake: handleStake }
}

export default useStake
