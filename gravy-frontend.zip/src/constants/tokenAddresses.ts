export const crops = '0x0e2298e3b3390e3b945a5456fbf59ecc3f55da16'
export const cropsv2 = '0xaba8cac6866b83ae4eec97dd07ed254282f6ad8a'
export const cropsAddress = '0x6443684816c822a75674aA48155f61F6B6CEdb92'
export const masterChefAddress = '0xb2AB07285348dfa41B9f339E491EE89BcB3aA4d1'
