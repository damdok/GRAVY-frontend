import React from 'react'
import styled from 'styled-components'
import Footer from '../Footer'
import Background from '../../assets/img/background.gif'

const Page: React.FC = ({ children }) => (
  <StyledPage>
    <StyledMain>{children}</StyledMain>
    <Footer />
  </StyledPage>
)

const StyledPage = styled.div`
  background: url(${Background}) no-repeat;
`

const StyledMain = styled.div`
  background: url(${Background}) no-repeat;
  align-items: center;
  display: flex;
  background-size:cover;
  background-position: center center;
  min-width: 100%;
  min-height: 999px;
  flex-direction: column;
`

export default Page
