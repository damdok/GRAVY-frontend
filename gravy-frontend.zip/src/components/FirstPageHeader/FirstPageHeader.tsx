import React from 'react'
import styled from 'styled-components'

import Container from '../Container'
import chef from '../../assets/img/chef.png'
import maintitlename from '../../assets/img/main-title-name.png'

interface PageHeaderProps {
  icon: React.ReactNode
  titleicon: React.ReactNode
  title?: string
}

const FirstPageHeader: React.FC<PageHeaderProps> = ({ icon, titleicon, title }) => {

  return (
    <Container size="sm">
      <StyledPageHeader>        
        <StyledIcon>            
          {icon}
        </StyledIcon>
        <StyledSubIcon>            
          {titleicon}
        </StyledSubIcon>
        <StyledSubtitle>{title}</StyledSubtitle>
      </StyledPageHeader>
    </Container>
  ) 
}



const StyledPageHeader = styled.div`
  align-items: center;
  box-sizing: border-box;
  display: flex;
  flex-direction: column;
  padding-bottom: ${(props) => props.theme.spacing[6]}px;
  padding-top: ${(props) => props.theme.spacing[6]}px;
  margin: 0 auto;
`

const StyledIcon = styled.div`
  font-size: 120px;
  height: 140px;
  line-height: 120px;
  text-align: center;
  width: 120px;
`

const StyledSubIcon = styled.div`
  font-size: 120px;
  height:80px;
  line-height: 60px;
  text-align: center;
  width: 300px;
`

const StyledSubtitle = styled.h3`
  color: #f8ff00;
  font-size: 30px;
  font-weight: 600;
  margin: 0;
  padding: 0;
  margin-top:15px;
  text-align: center;
`

export default FirstPageHeader
