import React from 'react'
import styled from 'styled-components'

interface LabelProps {
  text?: string
}

const AccountLabel: React.FC<LabelProps> = ({ text }) => (
  <StyledLabel>{text}</StyledLabel>
)

const StyledLabel = styled.div`
  color: #805e49;
  font-weight: bold;
`

export default AccountLabel
