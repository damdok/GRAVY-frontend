import React from 'react'
import styled from 'styled-components'

import Container from '../Container'

interface PageHeaderProps { 
  title?: string
}

const FirstPageHeader: React.FC<PageHeaderProps> = ({ title }) => {

  return (
    <Container size="sm">
      <StyledPageHeader>        
        <StyledSubtitle>{title}</StyledSubtitle>
      </StyledPageHeader>
    </Container>
  ) 
}



const StyledPageHeader = styled.div`
  align-items: center;
  box-sizing: border-box;
  display: flex;
  flex-direction: column;
  padding-bottom: ${(props) => props.theme.spacing[6]}px;
  padding-top: ${(props) => props.theme.spacing[6]}px;
  margin: 0 auto;
`


const StyledSubtitle = styled.h3`
  color: #131309;
  font-size: 30px;
  font-weight: 800;
  margin: 0;
  padding: 0;
  margin-top:15px;
  text-align: center;
`

export default FirstPageHeader
