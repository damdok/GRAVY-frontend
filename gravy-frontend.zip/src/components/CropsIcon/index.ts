export { default } from './CropsIcon'
