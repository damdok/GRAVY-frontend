import React from 'react'
import styled from 'styled-components'
import Spacer from '../../Spacer'

const Nav: React.FC = () => {
  return (
    <StyledNav>
      <FirstLink>
      <StyledLink
        href="https://app.uniswap.org/#/swap"
        target="_blank"
      >
        BUY GRVY
      </StyledLink>
      <StyledLink
        href="https://t.me/GravyTrain_rocks"
        target="_blank"
      >
        TELEGRAM
      </StyledLink> 

       
      </FirstLink>
      <SecondLink>
      
      
      <StyledLink
        href="https://github.com/gravytrainrocks"
        target="_blank"
      >
        GITHUB
      </StyledLink>

      <StyledLink
        href="https://twitter.com/GravyTrainRocks"
        target="_blank"
      >
        Twitter
      </StyledLink>
      </SecondLink>
    </StyledNav>
  )
}

const StyledNav = styled.nav`
  align-items: center;
  display: flex;
  @media(max-width:860px){
    flex-direction: column;
  }
`

const FirstLink = styled.div`
  display:flex;
  flex:50%;
  @media(max-width:860px){
    flex:100%;
    margin-top:5px;
  }
`
const SecondLink = styled.div`
  display:flex;
  flex:50%;
  @media(max-width:860px){
    flex:100%;
    margin-top:5px;
  } 
`

const StyledLink = styled.a`  
  color: #f8ff00;
  font-weight: 600;
  font-size: 20px;
  padding-left: ${(props) => props.theme.spacing[3]}px;
  padding-right: ${(props) => props.theme.spacing[3]}px;
  text-decoration: none;
  &:hover {
    color: ${(props) => props.theme.color.grey[500]};
  }
`


export default Nav
