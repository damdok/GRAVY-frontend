import React from 'react'
import { NavLink } from 'react-router-dom'
import styled from 'styled-components'

const Nav: React.FC = () => {
  return (
    <StyledNav>
      <FirstLink>
      <StyledLink exact activeClassName="active" to="/">
        Home
      </StyledLink>
      </FirstLink>
      <SecondLink>
      <StyledLink exact activeClassName="active" to="/farms">
        Farm
      </StyledLink>
  
      <StyledAbsoluteLink
        href="https://thegravytrainrocks.medium.com/"
        target="_blank"
      >
        About
      </StyledAbsoluteLink>
      </SecondLink>
    </StyledNav>
  )
}

const StyledNav = styled.nav`
  align-items: center;
  display: flex;
  @media(max-width:860px){
    flex-direction: column;
  }
`
const FirstLink = styled.div`
  display:flex;
  flex:40%;
  @media(max-width:860px){
    flex:100%;
    margin-top:5px;
  }
`
const SecondLink = styled.div`
  display:flex;
  flex:60%;
  @media(max-width:860px){
    flex:100%;
    margin-top:5px;
  } 
`


const StyledLink = styled(NavLink)`
  color: #f8ff00;
  font-weight: 600;
  font-size: 20px;
  font-weight: 700;
  padding-left: ${(props) => props.theme.spacing[3]}px;
  padding-right: ${(props) => props.theme.spacing[3]}px;
  text-decoration: none;
  &:hover {
    color: ${(props) => props.theme.color.grey[500]};
  }
  &.active {
    color: ${(props) => props.theme.color.primary.main};
  }
  @media (max-width: 400px) {
    padding-left: ${(props) => props.theme.spacing[2]}px;
    padding-right: ${(props) => props.theme.spacing[2]}px;
  }
`

const StyledAbsoluteLink = styled.a`
  color: #f8ff00;
  font-weight: 600;
  font-size: 20px;
  padding-left: ${(props) => props.theme.spacing[3]}px;
  padding-right: ${(props) => props.theme.spacing[3]}px;
  text-decoration: none;
  &:hover {
    color: ${(props) => props.theme.color.grey[500]};
  }
  &.active {
    color: ${(props) => props.theme.color.primary.main};
  }
  @media (max-width: 400px) {
    padding-left: ${(props) => props.theme.spacing[2]}px;
    padding-right: ${(props) => props.theme.spacing[2]}px;
  }
`

export default Nav
