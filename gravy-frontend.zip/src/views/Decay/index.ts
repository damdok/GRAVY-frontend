export { default } from './Decay'
