import BigNumber from 'bignumber.js'
import React, { useEffect, useState } from 'react'
import CountUp from 'react-countup'
import styled from 'styled-components'
import { useWallet } from 'use-wallet'
import Card from '../../../components/Card'
import CardContent from '../../../components/CardContent'
import Label from '../../../components/Label'
import Spacer from '../../../components/Spacer'
import Value from '../../../components/Value'
import CropsIcon from '../../../components/CropsIcon'
import useAllEarnings from '../../../hooks/useAllEarnings'
import useAllStakedValue from '../../../hooks/useAllStakedValue'
import useFarms from '../../../hooks/useFarms'
import useTokenBalance from '../../../hooks/useTokenBalance'
import useCrops from '../../../hooks/useCrops'
import { getCropsAddress, getCropsSupply } from '../../../crops/utils'
import { getBalanceNumber } from '../../../utils/formatBalance'

const PendingRewards: React.FC = () => {
  const [start, setStart] = useState(0)
  const [end, setEnd] = useState(0)
  const [scale, setScale] = useState(1)

  const allEarnings = useAllEarnings()
  let sumEarning = 0
  for (let earning of allEarnings) {
    sumEarning += new BigNumber(earning)
      .div(new BigNumber(10).pow(18))
      .toNumber()
  }

  const [farms] = useFarms()
  const allStakedValue = useAllStakedValue()

  if (allStakedValue && allStakedValue.length) {
    const sumWeth = farms.reduce(
      (c, { id }, i) => c + (allStakedValue[i].totalWethValue.toNumber() || 0),
      0,
    )
  }

  useEffect(() => {
    setStart(end)
    setEnd(sumEarning)
  }, [sumEarning])

  return (
    <span
      style={{
        transform: `scale(${scale})`,
        transformOrigin: 'right bottom',
        transition: 'transform 0.5s',
        display: 'inline-block',
      }}
    >
      <CountUp
        start={start}
        end={end}
        decimals={end < 0 ? 4 : end > 1e5 ? 0 : 3}
        duration={1}
        onStart={() => {
          setScale(1.25)
          setTimeout(() => setScale(1), 600)
        }}
        separator=","
      />
    </span>
  )
}

const Gravy: React.FC = () => {
  const [totalSupply, setTotalSupply] = useState<BigNumber>()
  const crops = useCrops()
  console.log("ksh crops address = ", getCropsAddress(crops))
  const cropsBalance = useTokenBalance(getCropsAddress(crops))
  const { account, ethereum }: { account: any; ethereum: any } = useWallet()

  useEffect(() => {
    async function fetchTotalSupply() {
      const supply = await getCropsSupply(crops)
      setTotalSupply(supply)
    }
    if (crops) {
      fetchTotalSupply()
    }
  }, [crops, setTotalSupply])

  return (
    <StyledWrapper>
      <GravyCard>
        <StyledBalances>
          <StyledBalance>
            <Spacer />
            <div style={{ flex: 1 }}>
              <Label text="Total GRVY Supply" />
              <Value
                value={!!account ? getBalanceNumber(cropsBalance) : 'Locked'}
              />
            </div>
          </StyledBalance>
        </StyledBalances>
        <Footnote>
          Pending Harvest
          <FootnoteValue>
            <PendingRewards /> GRVY
          </FootnoteValue>
        </Footnote>
      </GravyCard>
      <Spacer />

      <SpaceCard></SpaceCard>

      <GravyCard>
        <Label text="Total TRN Supply" />
        <Value
          value={totalSupply ? getBalanceNumber(totalSupply) : 'Locked'}
        />
        <Footnote>
          New Rewards per block
          <FootnoteValue>1 GRAVY</FootnoteValue>
        </Footnote>
      </GravyCard>
    </StyledWrapper>
  )
}

const Footnote = styled.div`
  font-size: 14px;
  padding: 8px 20px;
  color: white;
  text-align: center;
`
const FootnoteValue = styled.div`
  font-family: 'Arial-Rounded', sans-serif;
  float: right;
  margin-right: 20%;
`

const StyledWrapper = styled.div`
  align-items: center;
  display: flex;
  @media (max-width: 768px) {
    width: 100%;
    flex-flow: column nowrap;
    align-items: stretch;
  }
`

const StyledBalances = styled.div`
  display: flex;
`

const StyledBalance = styled.div`
  align-items: center;
  display: flex;
  flex: 1;
`
const GravyCard = styled.div`
  border-radius: 5px;
  display: flex;
  flex: 1;
  background-color:none;
  flex-direction: column;
  opacity: 0.8;
  text-align: center;
  padding: 20px 0px;
  margin: 0px 40px;
`
const SpaceCard = styled.div`
  flex: 1;
  margin: 0px 60px;
`

export default Gravy