import React from 'react'
import styled from 'styled-components'
import chef from '../../assets/img/chef.png'
import maintitlename from '../../assets/img/main-title-name.png'
import background from '../../assets/img/background.png'
import Button from '../../components/Button'
import Container from '../../components/Container'
import Page from '../../components/Page'
import FirstPageHeader from '../../components/FirstPageHeader'
import Spacer from '../../components/Spacer'
import Train from './components/Train'
import Gravy from './components/Gravy'

const Home: React.FC = () => {
  return (
    <Page>
      <FirstPageHeader
        icon={<img src={chef} height={160} />}
        titleicon={<img src={maintitlename} height={40} />}
        title="Stake Uniswap LP Tokens in Gravy Pools to earn GRVY tokens"
      />
        <Container>
          <Train />
          <Spacer size="lg" />
          <Gravy/>
          
        </Container>
        <StyledInfo>
        TRAIN Token is rewarded every 6500 blocks to a random farmer for the first 30 days
        </StyledInfo>
      
      
    </Page>
  )
}

const StyledInfo = styled.h3`
  font-family: 'Kaushan Script', sans-serif;
  color: #000;
  font-size: 25px;
  font-weight: 700;
  text-align: center;
  
`

export default Home
