export { default } from './Stake'
