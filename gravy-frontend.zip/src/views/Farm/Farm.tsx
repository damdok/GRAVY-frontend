import React, { useEffect, useMemo } from 'react'
import { useParams } from 'react-router-dom'
import styled from 'styled-components'
import { useWallet } from 'use-wallet'
import { provider } from 'web3-core'
import PageHeader from '../../components/PageHeader'
import Spacer from '../../components/Spacer'
import useFarm from '../../hooks/useFarm'
import useRedeem from '../../hooks/useRedeem'
import useCrops from '../../hooks/useCrops'
import { getMasterChefContract } from '../../crops/utils'
import { getContract } from '../../utils/erc20'
import Harvest from './components/Harvest'
import Stake from './components/Stake'

import train1 from '../../assets/img/train1.png'
import train2 from '../../assets/img/train2.png'
import train3 from '../../assets/img/train3.png'
import train4 from '../../assets/img/train4.png'

const Farm: React.FC = () => {
  const {farmId}  = useParams()
  console.log("farmId",farmId);
  const {
    pid,
    lpToken,
    lpTokenAddress,
    tokenAddress,
    earnToken,
    name,
    icon,
  } = useFarm(farmId) || {
    pid: 0,
    lpToken: '',
    lpTokenAddress: '',
    tokenAddress: '',
    earnToken: '',
    name: '',
    icon: '',
  }

  useEffect(() => {
    window.scrollTo(0, 0)
  }, [])

  const crops = useCrops()
  const { ethereum } = useWallet()

  const lpContract = useMemo(() => {
    return getContract(ethereum as provider, lpTokenAddress)
  }, [ethereum, lpTokenAddress])

  const { onRedeem } = useRedeem(getMasterChefContract(crops))

  const lpTokenName = useMemo(() => {
    return lpToken.toUpperCase()
  }, [lpToken])

  const earnTokenName = useMemo(() => {
    return earnToken.toUpperCase()
  }, [earnToken])

  return (
    <>
    <StyledTitle>
    {name}
    </StyledTitle>
      
      {farmId=="Deposit WETH-GRVY UNI-V2 LP Earn GRVY"
      ? <img src={train1} height="150" />
      : ''}
      {farmId=="Deposit WBTC-GRVY UNI-V2 LP Earn GRVY"
      ? <img src={train2} height="150" />
      : ''} 
      {farmId=="Deposit UNI-GRVY UNI-V2 LP Earn GRVY"
      ? <img src={train3} height="150" />
      : ''} 
      {farmId=="Deposit USDC-GRVY UNI-V2 LP Earn GRVY"
      ? <img src={train4} height="150" />
      : ''}
      <StyledSubtitle>
        {`${lpTokenName}  Tokens and earn GRVY`}
      </StyledSubtitle>
      
      <StyledFarm>
        <StyledCardsWrapper>
          <StyledCardWrapper>
            <Harvest pid={pid} />
          </StyledCardWrapper>
          <Spacer />
          <StyledCardWrapper>
            <Stake
              lpContract={lpContract}
              pid={pid}
              tokenName={lpToken.toUpperCase()}
            />
          </StyledCardWrapper>
        </StyledCardsWrapper>
        <Spacer size="lg" />
        
        <Spacer size="lg" />
      </StyledFarm>
    </>
  )
}

const StyledFarm = styled.div`
  align-items: center;
  display: flex;
  flex-direction: column;
  @media (max-width: 768px) {
    width: 100%;
  }
`

const StyledCardsWrapper = styled.div`
  display: flex;
  width: 600px;
  @media (max-width: 768px) {
    width: 100%;
    flex-flow: column nowrap;
    align-items: center;
  }
`

const StyledCardWrapper = styled.div`
  display: flex;
  flex: 1;
  flex-direction: column;
  @media (max-width: 768px) {
    width: 80%;
  }
`

const StyledInfo = styled.h3`
  color: ${(props) => props.theme.color.grey[400]};
  font-size: 16px;
  font-weight: 400;
  margin: 0;
  padding: 0;
  text-align: center;
`

const StyledTitle = styled.h1`
  font-family: 'Kaushan Script', sans-serif;
  color: #f8ff00;
  font-size: 36px;
  font-weight: 700;
  margin-top: 20px;
  padding: 0;
`

const StyledSubtitle = styled.h3`
  color: #fff;
  font-size: 20px;
  font-weight: 700;
  margin: 30px 0;
  padding: 0;
  text-align: center;
`

export default Farm
