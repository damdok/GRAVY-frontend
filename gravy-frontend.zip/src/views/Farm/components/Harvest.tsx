import React, { useState } from 'react'
import styled from 'styled-components'
import Button from '../../../components/PoolButton'
import Card from '../../../components/Card'
import CardContent from '../../../components/CardContent'
import CardIcon from '../../../components/CardIcon'
import Label from '../../../components/Label'
import Value from '../../../components/Value'
import useEarnings from '../../../hooks/useEarnings'
import useReward from '../../../hooks/useReward'
import CropsIcon from '../../../components/CropsIcon'
import { getBalanceNumber } from '../../../utils/formatBalance'
import tea from '../../../assets/img/tea.png'

import train1 from '../../../assets/img/train1.png'
import train2 from '../../../assets/img/train2.png'
import train3 from '../../../assets/img/train3.png'
import train4 from '../../../assets/img/train4.png'

interface HarvestProps {
  pid: number
}

const Harvest: React.FC<HarvestProps> = ({ pid }) => {
  const earnings = useEarnings(pid)
  const [pendingTx, setPendingTx] = useState(false)
  const { onReward } = useReward(pid)

  return (
    
        <StyledCardContentInner>
          <StyledCardHeader>
          <CardIcon>              
              {pid==0
              ? <img src={train1} height="40" />
              : ''}
              {pid==1
              ? <img src={train2} height="40" />
              : ''} 
              {pid==2
              ? <img src={train3} height="40" />
              : ''} 
              {pid==3
              ? <img src={train4} height="40" />
              : ''}
            </CardIcon>
            <Value value={getBalanceNumber(earnings)} />
            <StyledTitle>GRVY Earned</StyledTitle>
          </StyledCardHeader>
          <StyledCardActions>
            <Button
              disabled={!earnings.toNumber() || pendingTx}
              text={pendingTx ? 'Collecting GRVY' : 'Harvest'}
              onClick={async () => {
                setPendingTx(true)
                await onReward()
                setPendingTx(false)
              }}
            />
          </StyledCardActions>
        </StyledCardContentInner>
  )
}

const StyledCardHeader = styled.div`
  align-items: center;
  display: flex;
  flex-direction: column;
  margin-top: 15px;
`
const StyledCardActions = styled.div`
  display: flex;
  justify-content: center;
  margin-top: ${(props) => props.theme.spacing[6]}px;
  width: 100%;
`

const StyledTitle = styled.h4`
  color: #d4bc1a;
  font-size: 24px;
  font-weight: 700;
  margin: ${(props) => props.theme.spacing[2]}px 0 0;
  padding: 0;
  text-align:center;
  margin-bottom:10px;
  margin-top:20px;  
`


const StyledSpacer = styled.div`
  height: ${(props) => props.theme.spacing[4]}px;
  width: ${(props) => props.theme.spacing[4]}px;
`

const StyledCardContentInner = styled.div`
  align-items: center;
  display: flex;
  flex: 1;
  flex-direction: column;
  justify-content: space-between;
  background-color:#653332;
  opacity:0.9;
  width:295px;
`

export default Harvest
